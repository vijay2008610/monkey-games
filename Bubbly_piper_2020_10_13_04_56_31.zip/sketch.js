var player_running,player,banana,banana_img,bananaGroup,obstacle,obstacle_img,obstacleGroup,forest,forest_img,score,ground;

function preload (){
   
  forest_img = loadImage("jungle.jpng");
  player_running = loadImage("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  banana_img = loadImage("Banana.png");
  obstacle_img = loadImage("stone.png");

}


function setup() {
  createCanvas(400, 400);
  
  player = createSprite(100,350,30,40);
  player = addImage(player_running);
  player.scale=0.15;
  
  banana = createSprite(200,200,20,30);
  banana = addImage(banana_img );
  banana.scale=0.1;
  
  obstacle = createSprite(200,350,40,30);
  obstacle = addImage(obstacle_img);
  obstacle.scale=0.12;
  
  forest = createSprite(400,200);
  forest = addImage(forest_img);
  
  ground = createSprite(10,355,500,20);
  ground.visible=false;
}
function draw() {
  
   forest.velocityX=-4;
forest.x=forest.width/2;
  
  player.collide(ground);
  
  stroke("black");
textSize(20);
fill("black");
score=Math.ceil(frameCount/frameRate());
text("Score:"+score,100,50);

  if (keyDown("space")){
  player.velocityY=-14;
}
player.velocityY=player.velocityY + 0.8;

  if (bananaGroup.isTouching(player)){
  bananaGroup.destroyEach();
    score=score+1;
    switch (score){
      case 10 : player.scale = 0.12;
        break;
         case 20 : player.scale = 0.14;
        break;
         case 30 : player.scale = 0.16;
        break;
         case 40 : player.scale = 0.18;
        break;
        default : break;
    }
}
  
  if (obstacleGroup.isTouching(player)){
    player.scale=0.2;
  }
  

  stones();
food();
  
  
  drawSprites();
}

function food(){
  if (World.frameCount % 80 === 0){
    var fruit = createSprite(300,300,20,30);
    fruit.y=randomNumber(250,200);
    fruit.setAnimation("Banana");
    fruit.scale=0.05;
    fruit.velocityX=-3;
   fruit.lifetime=150;
    bananaGroup.add(fruit);
  }
}

function stones(){
  if (World.frameCount % 300 === 0){
    var stone = createSprite(248,318,30,40);
    stone.setAnimation("Stone");
    stone.x=randomNumber(150,250);
    stone.velocityX=-2;
    stone.lifetime=200;
    stone.scale=0.1;
    obstacleGroup.add(stone);
  }
}
